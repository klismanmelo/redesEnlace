#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <time.h>

#define PORT 8080
#define MAX_DATA_SIZE 1024
#define MAX_RETRIES 10
#define TIMEOUT_SEC 5

// Estrutura do quadro
struct Frame {
    int frame_number;
    unsigned int crc;
    char data[MAX_DATA_SIZE];
};

// Função para calcular CRC-32
unsigned int calculate_crc(char *data, int length) {
    unsigned int crc = 0xFFFFFFFF;
    for (int i = 0; i < length; i++) {
        crc ^= (unsigned int)(data[i]) << 24;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x80000000) {
                crc = (crc << 1) ^ 0x04C11DB7;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc ^ 0xFFFFFFFF;
}

// Função para enviar quadro e aguardar ACK/NACK com timeout
int send_and_wait_ack(int sockfd, struct sockaddr_in *server_addr, struct Frame *frame) {
    char response[10];
    socklen_t addr_len = sizeof(*server_addr);
    int retries = 0;

    while (retries < MAX_RETRIES) {
        // Calcular CRC e enviar quadro
        frame->crc = calculate_crc(frame->data, strlen(frame->data));
        sendto(sockfd, frame, sizeof(struct Frame), 0, (struct sockaddr *)server_addr, addr_len);
        printf("Enviado quadro %d (tentativa %d)\n", frame->frame_number, retries + 1);

        // Aguardar resposta com timeout usando select
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(sockfd, &readfds);
        struct timeval tv = {TIMEOUT_SEC, 0};

        int ready = select(sockfd + 1, &readfds, NULL, NULL, &tv);
        if (ready > 0) {
            // Receber resposta e verificar se vem do servidor
            struct sockaddr_in recv_addr;
            socklen_t recv_len = sizeof(recv_addr);
            int bytes = recvfrom(sockfd, response, sizeof(response), 0, (struct sockaddr *)&recv_addr, &recv_len);
            if (bytes > 0 && recv_addr.sin_addr.s_addr == server_addr->sin_addr.s_addr && recv_addr.sin_port == server_addr->sin_port) {
                response[bytes] = '\0';  // Null-terminate
                printf("Recebida resposta: %s\n", response);  // Debug: mostra a resposta recebida
                if (strcmp(response, "ACK") == 0) {
                    printf("Recebido ACK para quadro %d\n", frame->frame_number);
                    return 1; // Sucesso
                } else if (strcmp(response, "NACK") == 0) {
                    printf("Recebido NACK para quadro %d, retransmitindo\n", frame->frame_number);
                }
            } else {
                printf("Resposta de fonte desconhecida, ignorando\n");
            }
        } else if (ready == 0) {
            printf("Timeout para quadro %d, retransmitindo\n", frame->frame_number);
        } else {
            perror("Erro no select");
        }
        retries++;
    }
    printf("Falha após %d tentativas para quadro %d. Abortando transmissão.\n", MAX_RETRIES, frame->frame_number);
    return 0; // Falha
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <nome_do_arquivo>\n", argv[0]);
        exit(1);
    }

    // Abrir arquivo
    FILE *file = fopen(argv[1], "rb");
    if (!file) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }

    // Criar socket UDP
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Erro ao criar socket");
        exit(1);
    }

    // NOVO: Bind do socket do cliente a uma porta efêmera para receber respostas
    struct sockaddr_in client_addr;
    memset(&client_addr, 0, sizeof(client_addr));
    client_addr.sin_family = AF_INET;
    client_addr.sin_port = 0;  // Porta efêmera (sistema atribui)
    client_addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(sockfd, (struct sockaddr *)&client_addr, sizeof(client_addr)) < 0) {
        perror("Erro no bind do cliente");
        close(sockfd);
        exit(1);
    }

    // Configurar endereço do servidor
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Ler arquivo e enviar quadros
    struct Frame frame;
    int frame_number = 0;
    size_t bytes_read;
    while ((bytes_read = fread(frame.data, 1, MAX_DATA_SIZE, file)) > 0) {
        frame.frame_number = frame_number++;
        frame.data[bytes_read] = '\0'; // Null-terminate para strlen

        if (!send_and_wait_ack(sockfd, &server_addr, &frame)) {
            fclose(file);
            close(sockfd);
            exit(1);
        }
    }

    // Enviar quadro de fim (frame_number = -1)
    frame.frame_number = -1;
    strcpy(frame.data, "");
    if (!send_and_wait_ack(sockfd, &server_addr, &frame)) {
        fclose(file);
        close(sockfd);
        exit(1);
    }

    printf("Transmissão concluída com sucesso.\n");
    fclose(file);
    close(sockfd);
    return 0;
}
