#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

// Estrutura do quadro
struct Frame {
    int frame_number;
    unsigned int crc;
    char data[1024];  // MAX_DATA_SIZE
};

// Função para calcular CRC-32
unsigned int calculate_crc(char *data, int length) {
    unsigned int crc = 0xFFFFFFFF;
    for (int i = 0; i < length; i++) {
        crc ^= (unsigned int)(data[i]) << 24;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x80000000) {
                crc = (crc << 1) ^ 0x04C11DB7;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc ^ 0xFFFFFFFF;
}

// Função para configurar a porta serial
int configure_serial(const char *port) {
    int fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("Erro ao abrir porta serial");
        return -1;
    }

    struct termios options;
    tcgetattr(fd, &options);
    cfsetispeed(&options, B9600);  // Baud rate
    cfsetospeed(&options, B9600);
    options.c_cflag &= ~PARENB;    // Sem paridade
    options.c_cflag &= ~CSTOPB;    // 1 bit de parada
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;        // 8 bits de dados
    options.c_cflag |= CREAD | CLOCAL;  // Habilitar leitura e ignorar controle de modem
    options.c_iflag &= ~(IXON | IXOFF | IXANY);  // Sem controle de fluxo XON/XOFF
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);  // Modo raw
    options.c_oflag &= ~OPOST;     // Modo raw
    tcsetattr(fd, TCSANOW, &options);
    return fd;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <porta_serial>\n", argv[0]);
        exit(1);
    }

    const char *port = argv[1];

    // Configurar porta serial
    int fd = configure_serial(port);
    if (fd == -1) {
        exit(1);
    }

    printf("Servidor aguardando dados na porta serial...\n");

    // Loop para receber quadros
    struct Frame frame;
    while (1) {
        // Receber quadro
        int bytes = read(fd, &frame, sizeof(struct Frame));
        if (bytes == sizeof(struct Frame)) {
            printf("Recebido quadro %d\n", frame.frame_number);

            // Verificar se é quadro de fim
            if (frame.frame_number == -1) {
                write(fd, "ACK", 3);
                printf("Transmissão concluída.\n");
                break;
            }

            // Verificar CRC
            unsigned int calc_crc = calculate_crc(frame.data, strlen(frame.data));
            if (calc_crc == frame.crc) {
                write(fd, "ACK", 3);
                printf("CRC válido, enviado ACK\n");
            } else {
                write(fd, "NACK", 4);
                printf("CRC inválido, enviado NACK\n");
            }
        } else {
            printf("Erro na leitura do quadro\n");
        }
    }

    close(fd);
    return 0;
}
