#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <time.h>

#define MAX_DATA_SIZE 1024
#define MAX_RETRIES 10
#define TIMEOUT_SEC 5

// Estrutura do quadro
struct Frame {
    int frame_number;
    unsigned int crc;
    char data[MAX_DATA_SIZE];
};

// Função para calcular CRC-32
unsigned int calculate_crc(char *data, int length) {
    unsigned int crc = 0xFFFFFFFF;
    for (int i = 0; i < length; i++) {
        crc ^= (unsigned int)(data[i]) << 24;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x80000000) {
                crc = (crc << 1) ^ 0x04C11DB7;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc ^ 0xFFFFFFFF;
}

// Função para configurar a porta serial
int configure_serial(const char *port) {
    int fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("Erro ao abrir porta serial");
        return -1;
    }

    struct termios options;
    tcgetattr(fd, &options);
    cfsetispeed(&options, B9600);  // Baud rate
    cfsetospeed(&options, B9600);
    options.c_cflag &= ~PARENB;    // Sem paridade
    options.c_cflag &= ~CSTOPB;    // 1 bit de parada
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;        // 8 bits de dados
    options.c_cflag |= CREAD | CLOCAL;  // Habilitar leitura e ignorar controle de modem
    options.c_iflag &= ~(IXON | IXOFF | IXANY);  // Sem controle de fluxo XON/XOFF
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);  // Modo raw
    options.c_oflag &= ~OPOST;     // Modo raw
    tcsetattr(fd, TCSANOW, &options);
    return fd;
}

// Função para enviar quadro e aguardar ACK/NACK com timeout via serial
int send_and_wait_ack(int fd, struct Frame *frame) {
    char response[10];
    int retries = 0;

    while (retries < MAX_RETRIES) {
        // Calcular CRC e enviar quadro
        frame->crc = calculate_crc(frame->data, strlen(frame->data));
        write(fd, frame, sizeof(struct Frame));
        printf("Enviado quadro %d (tentativa %d)\n", frame->frame_number, retries + 1);

        // Aguardar resposta com timeout usando select
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(fd, &readfds);
        struct timeval tv = {TIMEOUT_SEC, 0};

        int ready = select(fd + 1, &readfds, NULL, NULL, &tv);
        if (ready > 0) {
            int bytes = read(fd, response, sizeof(response));
            if (bytes > 0) {
                response[bytes] = '\0';
                printf("Recebida resposta: %s\n", response);
                if (strcmp(response, "ACK") == 0) {
                    printf("Recebido ACK para quadro %d\n", frame->frame_number);
                    return 1; // Sucesso
                } else if (strcmp(response, "NACK") == 0) {
                    printf("Recebido NACK para quadro %d, retransmitindo\n", frame->frame_number);
                }
            }
        } else if (ready == 0) {
            printf("Timeout para quadro %d, retransmitindo\n", frame->frame_number);
        } else {
            perror("Erro no select");
        }
        retries++;
    }
    printf("Falha após %d tentativas para quadro %d. Abortando transmissão.\n", MAX_RETRIES, frame->frame_number);
    return 0; // Falha
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <porta_serial> <nome_do_arquivo>\n", argv[0]);
        exit(1);
    }

    const char *port = argv[1];
    const char *filename = argv[2];

    // Abrir arquivo
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }

    // Configurar porta serial
    int fd = configure_serial(port);
    if (fd == -1) {
        fclose(file);
        exit(1);
    }

    // Ler arquivo e enviar quadros
    struct Frame frame;
    int frame_number = 0;
    size_t bytes_read;
    while ((bytes_read = fread(frame.data, 1, MAX_DATA_SIZE, file)) > 0) {
        frame.frame_number = frame_number++;
        frame.data[bytes_read] = '\0'; // Null-terminate para strlen

        if (!send_and_wait_ack(fd, &frame)) {
            fclose(file);
            close(fd);
            exit(1);
        }
    }

    // Enviar quadro de fim (frame_number = -1)
    frame.frame_number = -1;
    strcpy(frame.data, "");
    if (!send_and_wait_ack(fd, &frame)) {
        fclose(file);
        close(fd);
        exit(1);
    }

    printf("Transmissão concluída com sucesso.\n");
    fclose(file);
    close(fd);
    return 0;
}
