#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_DATA_SIZE 1024

// Estrutura do quadro
struct Frame {
    int frame_number;
    unsigned int crc;
    char data[MAX_DATA_SIZE];
};

// Função para calcular CRC-32
unsigned int calculate_crc(char *data, int length) {
    unsigned int crc = 0xFFFFFFFF;
    for (int i = 0; i < length; i++) {
        crc ^= (unsigned int)(data[i]) << 24;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x80000000) {
                crc = (crc << 1) ^ 0x04C11DB7;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc ^ 0xFFFFFFFF;
}

int main() {
    // Criar socket UDP
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Erro ao criar socket");
        exit(1);
    }

    // Configurar endereço do servidor
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Erro no bind");
        exit(1);
    }

    printf("Servidor aguardando conexões...\n");

    // Loop para receber quadros
    struct Frame frame;
    socklen_t addr_len = sizeof(struct sockaddr_in);
    struct sockaddr_in client_addr;

    while (1) {
        // Receber quadro
        recvfrom(sockfd, &frame, sizeof(struct Frame), 0, (struct sockaddr *)&client_addr, &addr_len);
        printf("Recebido quadro %d\n", frame.frame_number);

        // Verificar se é quadro de fim
        if (frame.frame_number == -1) {
            sendto(sockfd, "ACK", 3, 0, (struct sockaddr *)&client_addr, addr_len);
            printf("Transmissão concluída.\n");
            break;
        }

        // Verificar CRC
        unsigned int calc_crc = calculate_crc(frame.data, strlen(frame.data));
        if (calc_crc == frame.crc) {
            sendto(sockfd, "ACK", 3, 0, (struct sockaddr *)&client_addr, addr_len);
            printf("CRC válido, enviado ACK\n");
        } else {
            sendto(sockfd, "NACK", 4, 0, (struct sockaddr *)&client_addr, addr_len);
            printf("CRC inválido, enviado NACK\n");
        }
    }

    close(sockfd);
    return 0;
}
